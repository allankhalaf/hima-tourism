// ═══════════════════════════════════════════════════════
// ملف JavaScript الرئيسي - index.js (هيما)
// ═══════════════════════════════════════════════════════

// استيراد Bootstrap CSS
import 'bootstrap/dist/css/bootstrap.rtl.min.css';

// استيراد Bootstrap Icons CSS
import 'bootstrap-icons/font/bootstrap-icons.css';

// استيراد jQuery
import $ from 'jquery';
window.$ = window.jQuery = $;

// استيراد ملف SCSS الرئيسي
import '../scss/main.scss';

// استيراد ملفات JavaScript المخصصة
import './carousel';
import './cart';
import './reviews';
import './validation';

console.log('🌍 هيما - موقع الرحلات السياحية والتخييم في سوريا');