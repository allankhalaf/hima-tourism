const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = {
  entry: {
    main: './src/js/index.js'  // ✅ اسم الـ chunk = 'main'
  },
  
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'js/[name].bundle.js',
    clean: true
  },
  
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [MiniCssExtractPlugin.loader, 'css-loader']
      },
      {
        test: /\.scss$/,
        use: [MiniCssExtractPlugin.loader, 'css-loader', 'sass-loader']
      }
    ]
  },
  
  // ✅ devServer داخل module.exports
  devServer: {
    static: {
      directory: path.join(__dirname, 'dist'),
    },
    historyApiFallback: {
      rewrites: [
        { from: /^\/pages\/.*$/, to: '/pages/index.html' }
      ]
    },
    hot: true,
    open: true
  },
  
  plugins: [
    new MiniCssExtractPlugin({
      filename: 'css/[name].css'
    }),
    
    // ✅ index.html في المسار الرئيسي
    new HtmlWebpackPlugin({
      template: path.resolve(__dirname, 'index.html'),
      filename: 'index.html',
      chunks: ['main']
    }),
    
    // ✅ الصفحات في مجلد pages/
    new HtmlWebpackPlugin({
      template: path.resolve(__dirname, 'pages/contact.html'),
      filename: 'pages/contact.html',
      chunks: ['main']
    }),
    
    new HtmlWebpackPlugin({
      template: path.resolve(__dirname, 'pages/checklist.html'),
      filename: 'pages/checklist.html',
      chunks: ['main']
    }),
    
    new HtmlWebpackPlugin({
      template: path.resolve(__dirname, 'pages/gallery.html'),
      filename: 'pages/gallery.html',
      chunks: ['main']
    }),
    
    new HtmlWebpackPlugin({
      template: path.resolve(__dirname, 'pages/planner.html'),
      filename: 'pages/planner.html',
      chunks: ['main']
    }),
    
    new CopyWebpackPlugin({
      patterns: [
        {
          from: path.resolve(__dirname, 'src/images'),
          to: path.resolve(__dirname, 'dist/images'),
          noErrorOnMissing: true
        }
      ]
    })
  ]
};