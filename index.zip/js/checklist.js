/**
 * Checklist Page - Interactive Equipment Guide
 * هيما - موقع السياحة الداخلية السورية
 * Features: Progress bar, dynamic calculations, rental system
 */

(function() {
  'use strict';

  // State management
  const state = {
    checkedItems: new Set(),
    rentedItems: new Map(),
    totalItems: 0,
    mountainItems: 0,
    safariItems: 0
  };

  // DOM Elements
  const mainProgressBar = document.getElementById('mainProgressBar');
  const progressPercentage = document.getElementById('progressPercentage');
  const progressStatus = document.getElementById('progressStatus');
  const checkedCount = document.getElementById('checkedCount');
  const uncheckedCount = document.getElementById('uncheckedCount');
  const rentedCount = document.getElementById('rentedCount');
  const mountainPercent = document.getElementById('mountainPercent');
  const safariPercent = document.getElementById('safariPercent');
  const rentedItemsCount = document.getElementById('rentedItemsCount');
  const totalRentCost = document.getElementById('totalRentCost');
  const summaryPercent = document.getElementById('summaryPercent');
  const rentalToast = document.getElementById('rentalToast');
  const rentalToastMessage = document.getElementById('rentalToastMessage');

  /**
   * Initialize checklist
   */
  function initChecklist() {
    const allItems = document.querySelectorAll('.checklist-item');
    state.totalItems = allItems.length;
    state.mountainItems = document.querySelectorAll('[data-category="mountain"]').length;
    state.safariItems = document.querySelectorAll('[data-category="safari"]').length;
    updateProgress();
    loadState();
  }

  /**
   * Update all progress indicators
   */
  window.updateProgress = function() {
    const checkboxes = document.querySelectorAll('.item-checkbox');
    const checked = document.querySelectorAll('.item-checkbox:checked');

    const total = checkboxes.length;
    const completed = checked.length;
    const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;

    mainProgressBar.style.width = percentage + '%';
    mainProgressBar.setAttribute('aria-valuenow', percentage);
    mainProgressBar.className = 'progress-bar progress-bar-striped progress-bar-animated';

    if (percentage < 30) {
      mainProgressBar.classList.add('bg-danger');
    } else if (percentage < 70) {
      mainProgressBar.classList.add('bg-warning');
    } else if (percentage < 100) {
      mainProgressBar.classList.add('bg-info');
    } else {
      mainProgressBar.classList.add('bg-success');
    }

    progressPercentage.textContent = percentage + '%';
    updateStatusMessage(percentage);
    checkedCount.textContent = completed;
    uncheckedCount.textContent = total - completed;
    rentedCount.textContent = state.rentedItems.size;
    updateSectionProgress();
    updateSummary();
    saveState();
  };

  function updateStatusMessage(percentage) {
    const messages = {
      0: 'ابدأ باختيار المعدات',
      25: 'بداية جيدة! استمر في التجهيز',
      50: 'أنت في منتصف الطريق',
      75: 'تقريباً جاهز! لا تنسَ الباقي',
      100: '🎉 أنت جاهز تماماً للمغامرة!'
    };
    let message = messages[0];
    for (const threshold in messages) {
      if (percentage >= parseInt(threshold)) {
        message = messages[threshold];
      }
    }
    progressStatus.textContent = message;
  }

  function updateSectionProgress() {
    const mountainChecked = document.querySelectorAll('[data-category="mountain"] .item-checkbox:checked').length;
    const mountainPercentValue = state.mountainItems > 0 
      ? Math.round((mountainChecked / state.mountainItems) * 100) : 0;
    mountainPercent.textContent = mountainPercentValue + '%';

    const safariChecked = document.querySelectorAll('[data-category="safari"] .item-checkbox:checked').length;
    const safariPercentValue = state.safariItems > 0 
      ? Math.round((safariChecked / state.safariItems) * 100) : 0;
    safariPercent.textContent = safariPercentValue + '%';
  }

  window.rentItem = function(btn, name, price, category) {
    const itemEl = btn.closest('.checklist-item');
    const itemId = itemEl.dataset.item;

    if (state.rentedItems.has(itemId)) {
      showToast('هذه الأداة مستأجرة بالفعل!', 'warning');
      return;
    }

    state.rentedItems.set(itemId, { name, price, category });

    if (typeof HimaCart !== 'undefined' && HimaCart.add) {
      HimaCart.add({
        id: 'rent-' + itemId,
        name: 'استئجار: ' + name,
        price: price
      });
    }

    btn.innerHTML = '<i class="bi bi-check-circle-fill"></i> مستأجر';
    btn.classList.add('rented');
    btn.disabled = true;

    const checkbox = itemEl.querySelector('.item-checkbox');
    if (!checkbox.checked) {
      checkbox.checked = true;
      updateProgress();
    }

    showToast('تمت إضافة "' + name + '" للسلة بـ ' + price.toLocaleString() + ' ل.س');
    updateSummary();
    saveState();
  };

  function updateSummary() {
    const rentedCount = state.rentedItems.size;
    let totalCost = 0;
    state.rentedItems.forEach(item => { totalCost += item.price; });

    rentedItemsCount.textContent = rentedCount + ' عنصر';
    totalRentCost.textContent = totalCost.toLocaleString() + ' ل.س';

    const totalChecked = document.querySelectorAll('.item-checkbox:checked').length;
    const total = document.querySelectorAll('.item-checkbox').length;
    summaryPercent.textContent = total > 0 ? Math.round((totalChecked / total) * 100) + '%' : '0%';
  }

  function showToast(message, type = 'success') {
    rentalToastMessage.textContent = message;
    rentalToast.className = 'rental-toast show';

    if (type === 'warning') {
      rentalToast.style.background = '#ffc107';
      rentalToast.style.color = '#000';
    } else {
      rentalToast.style.background = '#28a745';
      rentalToast.style.color = '#fff';
    }

    setTimeout(() => {
      rentalToast.classList.remove('show');
    }, 3000);
  }

  window.resetChecklist = function() {
    if (!confirm('هل أنت متأكد من إعادة تعيين القائمة؟')) return;

    document.querySelectorAll('.item-checkbox').forEach(cb => { cb.checked = false; });
    state.rentedItems.clear();
    document.querySelectorAll('.btn-rent').forEach(btn => {
      btn.innerHTML = '<i class="bi bi-cart-plus"></i> استئجار';
      btn.classList.remove('rented');
      btn.disabled = false;
    });

    updateProgress();
    localStorage.removeItem('himaChecklist');
    showToast('تم إعادة تعيين القائمة');
  };

  window.checkoutRentals = function() {
    if (state.rentedItems.size === 0) {
      showToast('لم تقم باستئجار أي أدوات بعد!', 'warning');
      return;
    }
    if (typeof toggleCart !== 'undefined') {
      toggleCart();
    } else {
      showToast('تم إضافة ' + state.rentedItems.size + ' عناصر للسلة!');
    }
  };

  function saveState() {
    const checkedIds = [];
    document.querySelectorAll('.item-checkbox:checked').forEach(cb => {
      checkedIds.push(cb.closest('.checklist-item').dataset.item);
    });
    const rentedArray = Array.from(state.rentedItems.entries());
    localStorage.setItem('himaChecklist', JSON.stringify({ checkedIds, rentedItems: rentedArray }));
  }

  function loadState() {
    const saved = localStorage.getItem('himaChecklist');
    if (!saved) return;
    try {
      const data = JSON.parse(saved);
      if (data.checkedIds) {
        data.checkedIds.forEach(id => {
          const item = document.querySelector(`[data-item="${id}"]`);
          if (item) item.querySelector('.item-checkbox').checked = true;
        });
      }
      if (data.rentedItems) {
        data.rentedItems.forEach(([id, itemData]) => {
          state.rentedItems.set(id, itemData);
          const item = document.querySelector(`[data-item="${id}"]`);
          if (item) {
            const btn = item.querySelector('.btn-rent');
            btn.innerHTML = '<i class="bi bi-check-circle-fill"></i> مستأجر';
            btn.classList.add('rented');
            btn.disabled = true;
          }
        });
      }
      updateProgress();
    } catch (e) {
      console.error('Error loading checklist state:', e);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initChecklist);
  } else {
    initChecklist();
  }

})();