/**
 * Planner Page - Multi-step Trip Planner with Live Price Calculator
 * هيما - موقع السياحة الداخلية السورية
 */

(function() {
  'use strict';

  let currentStep = 1;
  const totalSteps = 4;

  const destinationNames = {
    coast: 'الساحل السوري',
    desert: 'البادية السورية',
    qalamoun: 'جبال القلمون'
  };

  const activityNames = {
    hiking: 'مشي طويل',
    bedouin: 'سهرة بدوية',
    horse: 'ركوب خيل',
    camping: 'تخييم ليلي',
    photography: 'جولة تصوير',
    stargazing: 'مراقبة النجوم',
    cooking: 'طبخ تقليدي',
    camel: 'ركوب جمل'
  };

  const livePriceWidget = document.getElementById('livePriceWidget');
  const livePrice = document.getElementById('livePrice');
  const breakdownDestination = document.getElementById('breakdownDestination');
  const breakdownDays = document.getElementById('breakdownDays');
  const breakdownActivities = document.getElementById('breakdownActivities');
  const bookingModal = document.getElementById('bookingModal');

  function initPlanner() {
    setTimeout(() => { livePriceWidget.classList.add('show'); }, 500);
    updateStepIndicator();
    calculatePrice();
  }

  window.nextStep = function(step) {
    if (!validateStep(currentStep)) return;
    currentStep = step;
    showStep(currentStep);
    updateStepIndicator();
    updateSummary();
    document.querySelector('.planner-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  window.prevStep = function(step) {
    currentStep = step;
    showStep(currentStep);
    updateStepIndicator();
  };

  function showStep(step) {
    document.querySelectorAll('.form-step').forEach(el => { el.classList.remove('active'); });
    const targetStep = document.querySelector(`.form-step[data-step="${step}"]`);
    if (targetStep) targetStep.classList.add('active');
  }

  function updateStepIndicator() {
    document.querySelectorAll('.steps-progress .step').forEach((stepEl, index) => {
      const stepNum = index + 1;
      stepEl.classList.remove('active', 'completed');
      if (stepNum === currentStep) stepEl.classList.add('active');
      else if (stepNum < currentStep) stepEl.classList.add('completed');
    });
  }

  function validateStep(step) {
    switch(step) {
      case 1:
        if (!document.querySelector('input[name="destination"]:checked')) {
          showValidationError('الرجاء اختيار وجهة الرحلة'); return false;
        }
        return true;
      case 2:
        const days = parseInt(document.getElementById('tripDays').value);
        if (!days || days < 1) {
          showValidationError('الرجاء تحديد عدد أيام الرحلة'); return false;
        }
        return true;
      default: return true;
    }
  }

  function showValidationError(message) {
    const toast = document.createElement('div');
    toast.className = 'planner-toast error';
    toast.innerHTML = `<i class="bi bi-exclamation-triangle-fill"></i> ${message}`;
    document.body.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  window.calculatePrice = function() {
    let totalPrice = 0;
    let destinationPrice = 0;
    let destinationName = '-';
    let days = 0;
    let activitiesTotal = 0;

    const destination = document.querySelector('input[name="destination"]:checked');
    if (destination) {
      destinationPrice = parseInt(destination.dataset.price) || 0;
      destinationName = destinationNames[destination.value] || destination.value;
      totalPrice += destinationPrice;
    }

    const daysInput = document.getElementById('tripDays');
    if (daysInput) {
      days = parseInt(daysInput.value) || 1;
      totalPrice *= days;
    }

    const activities = document.querySelectorAll('input[name="activities"]:checked');
    activities.forEach(activity => {
      activitiesTotal += parseInt(activity.dataset.price) || 0;
    });
    totalPrice += activitiesTotal;

    animatePrice(livePrice, parseInt(livePrice.textContent.replace(/,/g, '')) || 0, totalPrice);
    breakdownDestination.textContent = destinationName;
    breakdownDays.textContent = days + ' × ' + (destinationPrice > 0 ? destinationPrice.toLocaleString() : '0');
    breakdownActivities.textContent = activitiesTotal.toLocaleString() + ' ل.س';
    savePlannerState();
  };

  function animatePrice(element, from, to) {
    const duration = 500;
    const startTime = performance.now();
    function update(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeOut = 1 - Math.pow(1 - progress, 3);
      const current = Math.floor(from + (to - from) * easeOut);
      element.textContent = current.toLocaleString();
      if (progress < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
  }

  window.changeDays = function(delta) {
    const input = document.getElementById('tripDays');
    let value = parseInt(input.value) || 1;
    value += delta;
    if (value < 1) value = 1;
    if (value > 14) value = 14;
    input.value = value;
    updateDurationText(value);
    calculatePrice();
  };

  window.setDays = function(days) {
    const input = document.getElementById('tripDays');
    input.value = days;
    updateDurationText(days);
    calculatePrice();
  };

  function updateDurationText(days) {
    const textEl = document.getElementById('durationText');
    let text = '';
    if (days === 1) text = 'يوم واحد';
    else if (days === 2) text = 'يومان';
    else if (days >= 3 && days <= 10) text = days + ' أيام';
    else text = days + ' يوم';
    textEl.textContent = text;
  }

  function updateSummary() {
    const destination = document.querySelector('input[name="destination"]:checked');
    const days = document.getElementById('tripDays').value;
    const activities = document.querySelectorAll('input[name="activities"]:checked');

    document.getElementById('summaryDestination').textContent = 
      destination ? destinationNames[destination.value] : '-';

    let durationText = days + ' ';
    if (days == 1) durationText += 'يوم';
    else if (days == 2) durationText += 'يومان';
    else durationText += 'أيام';
    document.getElementById('summaryDuration').textContent = durationText;

    if (activities.length === 0) {
      document.getElementById('summaryActivities').textContent = 'لا توجد أنشطة مختارة';
    } else {
      const activityList = Array.from(activities).map(a => activityNames[a.value]).join('، ');
      document.getElementById('summaryActivities').textContent = activityList;
    }

    const total = parseInt(livePrice.textContent.replace(/,/g, '')) || 0;
    document.getElementById('summaryTotal').textContent = total.toLocaleString() + ' ل.س';
  }

  window.submitBooking = function() {
    const name = document.getElementById('bookingName').value.trim();
    const phone = document.getElementById('bookingPhone').value.trim();

    if (!name) { showValidationError('الرجاء إدخال اسمك الكامل'); return; }
    if (!phone) { showValidationError('الرجاء إدخال رقم الهاتف'); return; }

    const destination = document.querySelector('input[name="destination"]:checked');
    const days = document.getElementById('tripDays').value;
    const activities = document.querySelectorAll('input[name="activities"]:checked');
    const total = livePrice.textContent;

    const detailsHTML = `
      <div class="modal-detail-item"><span>الوجهة:</span><strong>${destination ? destinationNames[destination.value] : '-'}</strong></div>
      <div class="modal-detail-item"><span>المدة:</span><strong>${days} أيام</strong></div>
      <div class="modal-detail-item"><span>التكلفة:</span><strong>${total} ل.س</strong></div>
    `;

    document.getElementById('modalDetails').innerHTML = detailsHTML;
    bookingModal.classList.add('active');
    document.body.style.overflow = 'hidden';

    saveBooking({
      name, phone,
      destination: destination ? destination.value : '',
      days,
      activities: Array.from(activities).map(a => a.value),
      total,
      date: new Date().toISOString()
    });
    localStorage.removeItem('himaPlanner');
  };

  window.closeBookingModal = function() {
    bookingModal.classList.remove('active');
    document.body.style.overflow = '';
    window.location.href = '../index.html';
  };

  function savePlannerState() {
    const state = {
      destination: document.querySelector('input[name="destination"]:checked')?.value || '',
      days: document.getElementById('tripDays').value,
      activities: Array.from(document.querySelectorAll('input[name="activities"]:checked')).map(a => a.value),
      currentStep
    };
    localStorage.setItem('himaPlanner', JSON.stringify(state));
  }

  function loadPlannerState() {
    const saved = localStorage.getItem('himaPlanner');
    if (!saved) return;
    try {
      const state = JSON.parse(saved);
      if (state.destination) {
        const destInput = document.querySelector(`input[name="destination"][value="${state.destination}"]`);
        if (destInput) destInput.checked = true;
      }
      if (state.days) {
        document.getElementById('tripDays').value = state.days;
        updateDurationText(parseInt(state.days));
      }
      if (state.activities) {
        state.activities.forEach(act => {
          const input = document.querySelector(`input[name="activities"][value="${act}"]`);
          if (input) input.checked = true;
        });
      }
      calculatePrice();
    } catch (e) { console.error('Error loading planner state:', e); }
  }

  function saveBooking(booking) {
    const bookings = JSON.parse(localStorage.getItem('himaBookings') || '[]');
    bookings.push(booking);
    localStorage.setItem('himaBookings', JSON.stringify(bookings));
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { initPlanner(); loadPlannerState(); });
  } else {
    initPlanner(); loadPlannerState();
  }

})();