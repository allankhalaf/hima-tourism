/**
 * Gallery Page - Interactive Filtering System
 * هيما - موقع السياحة الداخلية السورية
 */

(function() {
  'use strict';

  // DOM Elements
  const filterButtons = document.querySelectorAll('.filter-btn');
  const galleryItems = document.querySelectorAll('.gallery-item');
  const noResults = document.getElementById('noResults');
  const lightboxModal = document.getElementById('lightboxModal');
  const lightboxImage = document.getElementById('lightboxImage');
  const lightboxCaption = document.getElementById('lightboxCaption');

  // Lightbox data for each destination
  const lightboxData = {
    palmyra: {
      src: '../images/palmyra.jpg',
      caption: 'آثار تدمر - مدينة النخيل الأثرية، واحدة من أهم المدن القديمة في العالم'
    },
    krak: {
      src: '../images/Alhussen.jpg',
      caption: 'قلعة الحصن - أحد أهم القلاع الصليبية في الشرق الأوسط'
    },
    kasab: {
      src: '../images/kasab.jpg',
      caption: 'كسب - قرية ساحلية ساحرة تطل على البحر الأبيض المتوسط'
    },
    mashta: {
      src: '../images/mashta.jpg',
      caption: 'مشتى الحلو - قرية جبلية خلابة تتميز بأشجار الصنوبر'
    },
    badia: {
      src: '../images/badia.jpg',
      caption: 'بادية الشام - صحراء شاسعة تمتد عبر سوريا والعراق والأردن'
    },
    slenfeh: {
      src: '../images/slenfeh.jpg',
      caption: 'صلنفة - قرية جبلية تطل على الساحل السوري من ارتفاع 1130 متراً'
    },
    abwab: {
      src: '../images/abwab.jpg',
      caption: 'أبواب الهوى - موقع أثري يعود للعصر الروماني'
    },
    qalamoun: {
      src: '../images/qalamoun.jpg',
      caption: 'جبال القلمون - سلسلة جبلية خلابة تتميز بغابات الصنوبر والأرز'
    },
    safita: {
      src: '../images/safita.jpg',
      caption: 'صافيتا - مدينة ساحلية تاريخية تضم برج صافيتا الصليبي'
    },
    maarat: {
      src: '../images/maarat.jpg',
      caption: 'معرة النعمان - تضم متحف الفسيفساء الأكبر في الشرق الأوسط'
    }
  };

  /**
   * Initialize gallery filtering
   */
  function initGallery() {
    // Check URL params for pre-selected filter
    const urlParams = new URLSearchParams(window.location.search);
    const filterParam = urlParams.get('filter');

    if (filterParam && ['historical', 'nature', 'coastal'].includes(filterParam)) {
      const targetBtn = document.querySelector(`[data-filter="${filterParam}"]`);
      if (targetBtn) {
        filterButtons.forEach(btn => btn.classList.remove('active'));
        targetBtn.classList.add('active');
        filterGallery(filterParam);
      }
    }

    // Attach click handlers to filter buttons
    filterButtons.forEach(button => {
      button.addEventListener('click', function() {
        const filter = this.dataset.filter;

        // Update active state
        filterButtons.forEach(btn => btn.classList.remove('active'));
        this.classList.add('active');

        // Apply filter
        filterGallery(filter);

        // Update URL without reload
        const url = new URL(window.location);
        if (filter === 'all') {
          url.searchParams.delete('filter');
        } else {
          url.searchParams.set('filter', filter);
        }
        window.history.replaceState({}, '', url);
      });
    });

    // Close lightbox on background click
    lightboxModal.addEventListener('click', function(e) {
      if (e.target === lightboxModal) {
        closeLightbox();
      }
    });

    // Close lightbox on Escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && lightboxModal.classList.contains('active')) {
        closeLightbox();
      }
    });
  }

  /**
   * Filter gallery items with smooth animation
   * @param {string} category - The filter category
   */
  function filterGallery(category) {
    let visibleCount = 0;

    galleryItems.forEach((item, index) => {
      const itemCategory = item.dataset.category;
      const shouldShow = category === 'all' || itemCategory === category;

      if (shouldShow) {
        // Show item with staggered animation
        item.style.display = '';
        setTimeout(() => {
          item.classList.add('show');
          item.classList.remove('hide');
        }, index * 50);
        visibleCount++;
      } else {
        // Hide item
        item.classList.add('hide');
        item.classList.remove('show');
        setTimeout(() => {
          item.style.display = 'none';
        }, 300);
      }
    });

    // Show/hide no results message
    if (visibleCount === 0) {
      setTimeout(() => {
        noResults.style.display = 'block';
        noResults.classList.add('show');
      }, 300);
    } else {
      noResults.classList.remove('show');
      setTimeout(() => {
        noResults.style.display = 'none';
      }, 300);
    }
  }

  // Expose lightbox functions globally
  window.openLightbox = function(key) {
    const data = lightboxData[key];
    if (!data) return;

    lightboxImage.src = data.src;
    lightboxCaption.textContent = data.caption;
    lightboxModal.classList.add('active');
    document.body.style.overflow = 'hidden';
  };

  window.closeLightbox = function() {
    lightboxModal.classList.remove('active');
    document.body.style.overflow = '';
    setTimeout(() => {
      lightboxImage.src = '';
    }, 300);
  };

  // Initialize on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initGallery);
  } else {
    initGallery();
  }

})();